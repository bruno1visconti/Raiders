import { RaiderApp } from '@/components/raider-app'

export default function Page() {
  return <RaiderApp />
}

