export type ContentStatus = "pendiente" | "en_proceso" | "aprobado"

export type ProgressContent = {
  id: string
  area: string
  titulo: string
  estado: ContentStatus
}

export type Raider = {
  dni: string
  pin: string
  nombre: string
  patrulla: string
  etapa_actual: string
  insignia_ala: string
  experiencia_xp: number
  proxima_meta: string
  contenidos_minimos: ProgressContent[]
  licencias: { id: string; nombre: string; desbloqueada: boolean }[]
  empresas: { nombre: string; rol: string; estado: string }[]
}

export const raiderDatabase = {
  comunidad_raider: {
    nombre_grupo: "Comunidad Raider N° 1",
    raiders: [
      {
        dni: "45123456",
        pin: "1234",
        nombre: "Lucas González",
        patrulla: "Yámanas",
        etapa_actual: "Investidura",
        insignia_ala: "Fondo Azul",
        experiencia_xp: 1450,
        proxima_meta: "Realizar Raid de Compromiso",
        contenidos_minimos: [
          { id: "AS01", area: "Artes Scouts", titulo: "Amarre Cuadrado y Diagonal", estado: "aprobado" },
          { id: "AS02", area: "Artes Scouts", titulo: "Construcción de Mangrullo de 3m", estado: "en_proceso" },
          { id: "AS03", area: "Artes Scouts", titulo: "Cabuyería y nudos de rescate", estado: "pendiente" },
          { id: "VA01", area: "Vida al Aire Libre", titulo: "Lectura de Carta Topográfica y Brújula", estado: "aprobado" },
          { id: "VA02", area: "Vida al Aire Libre", titulo: "Cocina de campamento para la patrulla", estado: "en_proceso" },
          { id: "VA03", area: "Vida al Aire Libre", titulo: "Diseño de un refugio de emergencia", estado: "pendiente" },
          { id: "PA01", area: "Primeros Auxilios", titulo: "RCP y Vendajes de Rescate", estado: "pendiente" },
          { id: "PA02", area: "Primeros Auxilios", titulo: "Protocolo ante una emergencia", estado: "pendiente" },
          { id: "EX01", area: "Expresión", titulo: "Animación y fogón de patrulla", estado: "aprobado" },
          { id: "EX02", area: "Expresión", titulo: "Comunicación en una actividad", estado: "en_proceso" },
          { id: "ES01", area: "Animación Espiritual", titulo: "Vivencia de la Oración Raider", estado: "aprobado" },
          { id: "ES02", area: "Animación Espiritual", titulo: "Reflexión personal en la naturaleza", estado: "pendiente" },
          { id: "CI01", area: "Ciudadanía", titulo: "Servicio comunitario en el barrio", estado: "en_proceso" },
          { id: "CI02", area: "Ciudadanía", titulo: "Conocer y ejercer mis derechos", estado: "pendiente" },
          { id: "VS01", area: "Vida Scout", titulo: "Ley, Promesa y espíritu Raider", estado: "aprobado" },
          { id: "VS02", area: "Vida Scout", titulo: "Planificación de una salida", estado: "en_proceso" },
        ] satisfies ProgressContent[],
        licencias: [
          { id: "LIC01", nombre: "Pionerismo y Construcciones", desbloqueada: true },
          { id: "LIC02", nombre: "Primeros Auxilios y Salvamento", desbloqueada: false },
          { id: "LIC03", nombre: "Cartografía y Orientación", desbloqueada: true },
          { id: "ESP01", nombre: "Vida en la Naturaleza", desbloqueada: false },
          { id: "ESP02", nombre: "Servicio Comunitario", desbloqueada: false },
          { id: "ESP03", nombre: "Animación y Expresión", desbloqueada: true },
        ],
        empresas: [
          { nombre: "Remodelación Base-Taller", rol: "Encargado de Estructura", estado: "En Ejecución" },
          { nombre: "Campamento de Verano", rol: "Logística de Intendencia", estado: "Finalizada" },
          { nombre: "Sendero accesible del barrio", rol: "Equipo de servicio", estado: "En planificación" },
        ],
      },
    ],
  },
}

export const contentAreas = [
  "Artes Scouts",
  "Vida al Aire Libre",
  "Primeros Auxilios",
  "Expresión",
  "Animación Espiritual",
  "Ciudadanía",
  "Vida Scout",
]

export const statusLabels: Record<ContentStatus, string> = {
  pendiente: "Pendiente",
  en_proceso: "En proceso",
  aprobado: "Aprobado",
}

export const statusCycle: Record<ContentStatus, ContentStatus> = {
  pendiente: "en_proceso",
  en_proceso: "aprobado",
  aprobado: "pendiente",
}

export function getLicenseUnlockState(
  raider: Raider,
  licenseId: string,
): boolean {
  const approvedIn = (area: string) =>
    raider.contenidos_minimos.filter(
      (content) => content.area === area && content.estado === "aprobado",
    ).length

  if (licenseId === "LIC01") return approvedIn("Artes Scouts") >= 1
  if (licenseId === "LIC02") return approvedIn("Primeros Auxilios") >= 2
  if (licenseId === "LIC03") return approvedIn("Vida al Aire Libre") >= 1
  if (licenseId === "ESP01") return approvedIn("Vida al Aire Libre") >= 2
  if (licenseId === "ESP02") return approvedIn("Ciudadanía") >= 2
  if (licenseId === "ESP03") return approvedIn("Expresión") >= 1
  return false
}

export function getLicenseRequirement(licenseId: string) {
  if (licenseId === "LIC01") return "Aprobá un contenido de Artes Scouts"
  if (licenseId === "LIC02") return "Aprobá 2 contenidos de Primeros Auxilios"
  if (licenseId === "LIC03") return "Aprobá un contenido de Vida al Aire Libre"
  if (licenseId === "ESP01") return "Aprobá 2 contenidos de Vida al Aire Libre"
  if (licenseId === "ESP02") return "Aprobá 2 contenidos de Ciudadanía"
  return "Aprobá un contenido de Expresión"
}

export function formatDni(value: string) {
  return new Intl.NumberFormat("es-AR").format(Number(value))
}

export function getProgressSummary(raider: Raider) {
  const total = raider.contenidos_minimos.length
  const approved = raider.contenidos_minimos.filter(
    (content) => content.estado === "aprobado",
  ).length
  return { total, approved, percentage: total ? Math.round((approved / total) * 100) : 0 }
}

export function getExperience(raider: Raider) {
  const baseApproved = 5
  const currentApproved = raider.contenidos_minimos.filter(
    (content) => content.estado === "aprobado",
  ).length
  return Math.max(0, raider.experiencia_xp + (currentApproved - baseApproved) * 100)
}

export function getInitialRaider(dni: string) {
  return raiderDatabase.comunidad_raider.raiders.find((raider) => raider.dni === dni)
}

export function getAvatarInitials(name: string) {
  return name
    .split(" ")
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase()
}

export const areaIcons: Record<string, string> = {
  "Artes Scouts": "⌁",
  "Vida al Aire Libre": "⌖",
  "Primeros Auxilios": "+",
  Expresión: "♫",
  "Animación Espiritual": "✧",
  Ciudadanía: "⌂",
  "Vida Scout": "⚑",
}

export const areaColors: Record<string, string> = {
  "Artes Scouts": "bg-[#e6eee3] text-[#4d724c]",
  "Vida al Aire Libre": "bg-[#e7eddf] text-[#66803e]",
  "Primeros Auxilios": "bg-[#f7e8e3] text-[#b05f48]",
  Expresión: "bg-[#f3e9d8] text-[#a47732]",
  "Animación Espiritual": "bg-[#efe8f4] text-[#87669b]",
  Ciudadanía: "bg-[#e3edf0] text-[#527c88]",
  "Vida Scout": "bg-[#f2e8d4] text-[#a47e35]",
}

export const licenseIcons: Record<string, string> = {
  LIC01: "⚒",
  LIC02: "+",
  LIC03: "⌖",
  ESP01: "♧",
  ESP02: "⌂",
  ESP03: "♫",
}

export const progressionMilestones = [
  { name: "Noviciado", label: "Primeros pasos", state: "complete" },
  { name: "Investidura", label: "Tu etapa actual", state: "current" },
  { name: "Licencia de Servicio", label: "El próximo gran desafío", state: "upcoming" },
]

export const navigationItems = [
  { id: "avatar", label: "Mi Avatar", icon: "user" },
  { id: "arbol", label: "Árbol de progresión", icon: "tree" },
  { id: "licencias", label: "Licencias y especialidades", icon: "badge" },
  { id: "empresas", label: "Mis empresas", icon: "flag" },
] as const

export type SectionId = (typeof navigationItems)[number]["id"]

export function getNextObjective(raider: Raider) {
  return raider.contenidos_minimos.find((content) => content.estado !== "aprobado")
}

export function getApprovedCountInArea(raider: Raider, area: string) {
  return raider.contenidos_minimos.filter(
    (content) => content.area === area && content.estado === "aprobado",
  ).length
}

export function getExperienceProgress(raider: Raider) {
  return getExperience(raider) % 500
}

export function getStageCopy(stage: string) {
  if (stage === "Noviciado") return "Descubriendo el camino"
  if (stage === "Licencia de Servicio") return "Al servicio de los demás"
  return "El camino se hace al andar"
}

export function getStageColor(stage: string) {
  if (stage === "Noviciado") return "from-[#6e8758] to-[#415d42]"
  if (stage === "Licencia de Servicio") return "from-[#bd9651] to-[#87652e]"
  return "from-[#527b83] to-[#35585f]"
}

export function getCompanyStatusStyle(status: string) {
  if (status === "Finalizada") return "border-[#cfddc9] bg-[#edf3e9] text-[#56714e]"
  if (status === "En Ejecución") return "border-[#ead9b7] bg-[#f8f0df] text-[#987638]"
  return "border-[#d6e1e4] bg-[#edf3f4] text-[#527881]"
}

export function getDniDigits(value: string) {
  return value.replace(/\D/g, "").slice(0, 8)
}

export function formatExperience(value: number) {
  return new Intl.NumberFormat("es-AR").format(value)
}

export function getAreaContentCount(raider: Raider, area: string) {
  return raider.contenidos_minimos.filter((content) => content.area === area).length
}

export function getAreaApprovedCount(raider: Raider, area: string) {
  return raider.contenidos_minimos.filter(
    (content) => content.area === area && content.estado === "aprobado",
  ).length
}

export function getAreaProgress(raider: Raider, area: string) {
  const total = getAreaContentCount(raider, area)
  return total ? Math.round((getAreaApprovedCount(raider, area) / total) * 100) : 0
}

export function getInitials(name: string) {
  return name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0])
    .join("")
    .toUpperCase()
}

export function getExperienceLevel(raider: Raider) {
  return Math.floor(getExperience(raider) / 500) + 1
}

export function getXPToNextLevel(raider: Raider) {
  return 500 - getExperience(raider) % 500
}

export function getContentStatusCounts(raider: Raider) {
  return raider.contenidos_minimos.reduce(
    (counts, content) => {
      counts[content.estado] += 1
      return counts
    },
    { pendiente: 0, en_proceso: 0, aprobado: 0 },
  )
}
