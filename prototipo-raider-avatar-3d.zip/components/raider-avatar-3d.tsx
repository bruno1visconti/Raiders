'use client'

import { useRef, useSyncExternalStore } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { ContactShadows, OrbitControls } from '@react-three/drei'
import type { Group } from 'three'

const motionPreference = '(prefers-reduced-motion: reduce)'

function subscribeToMotionPreference(onChange: () => void) {
  const mediaQuery = window.matchMedia(motionPreference)
  mediaQuery.addEventListener('change', onChange)
  return () => mediaQuery.removeEventListener('change', onChange)
}

function getMotionPreference() {
  return window.matchMedia(motionPreference).matches
}

function useReducedMotion() {
  return useSyncExternalStore(subscribeToMotionPreference, getMotionPreference, () => true)
}

function Badge({ position, rotation = [0, 0, 0] as [number, number, number], color = '#e5c96d' }: { position: [number, number, number]; rotation?: [number, number, number]; color?: string }) {
  return (
    <mesh position={position} rotation={rotation} castShadow>
      <cylinderGeometry args={[0.045, 0.045, 0.018, 8]} />
      <meshStandardMaterial color={color} metalness={0.45} roughness={0.42} />
    </mesh>
  )
}

function RaiderCharacter() {
  const group = useRef<Group>(null)
  const reduceMotion = useReducedMotion()

  useFrame(({ clock }) => {
    if (!group.current || reduceMotion) return
    group.current.position.y = Math.sin(clock.elapsedTime * 1.6) * 0.012
  })

  return (
    <group ref={group} position={[0, 0.03, 0]}>
      {/* Legs / boots */}
      <mesh position={[-0.105, 0.34, 0]} castShadow>
        <capsuleGeometry args={[0.075, 0.28, 6, 10]} />
        <meshStandardMaterial color="#5d6651" roughness={0.88} />
      </mesh>
      <mesh position={[0.105, 0.34, 0]} castShadow>
        <capsuleGeometry args={[0.075, 0.28, 6, 10]} />
        <meshStandardMaterial color="#5d6651" roughness={0.88} />
      </mesh>
      <mesh position={[-0.105, 0.115, 0.035]} castShadow>
        <boxGeometry args={[0.17, 0.105, 0.28]} />
        <meshStandardMaterial color="#302c27" roughness={0.95} />
      </mesh>
      <mesh position={[0.105, 0.115, 0.035]} castShadow>
        <boxGeometry args={[0.17, 0.105, 0.28]} />
        <meshStandardMaterial color="#302c27" roughness={0.95} />
      </mesh>

      {/* Torso / uniform */}
      <mesh position={[0, 0.68, 0]} castShadow>
        <capsuleGeometry args={[0.215, 0.34, 6, 12]} />
        <meshStandardMaterial color="#536847" roughness={0.82} />
      </mesh>
      <mesh position={[0, 0.69, 0.205]}>
        <boxGeometry args={[0.16, 0.13, 0.018]} />
        <meshStandardMaterial color="#d7c58a" roughness={0.7} />
      </mesh>
      <mesh position={[0, 0.69, 0.222]} rotation={[0, 0, Math.PI / 4]}>
        <octahedronGeometry args={[0.047, 0]} />
        <meshStandardMaterial color="#e7ca68" metalness={0.4} roughness={0.4} />
      </mesh>

      {/* Backpack */}
      <mesh position={[0, 0.76, -0.19]} castShadow>
        <boxGeometry args={[0.29, 0.38, 0.16]} />
        <meshStandardMaterial color="#7b5638" roughness={0.94} />
      </mesh>
      <mesh position={[0, 0.93, -0.285]}>
        <cylinderGeometry args={[0.065, 0.065, 0.12, 12]} />
        <meshStandardMaterial color="#4b3829" roughness={1} />
      </mesh>

      {/* Arms */}
      <mesh position={[-0.255, 0.68, 0]} rotation={[0, 0, -0.16]} castShadow>
        <capsuleGeometry args={[0.065, 0.29, 6, 10]} />
        <meshStandardMaterial color="#536847" roughness={0.85} />
      </mesh>
      <mesh position={[0.255, 0.68, 0]} rotation={[0, 0, 0.16]} castShadow>
        <capsuleGeometry args={[0.065, 0.29, 6, 10]} />
        <meshStandardMaterial color="#536847" roughness={0.85} />
      </mesh>
      <mesh position={[-0.27, 0.47, 0.02]}>
        <sphereGeometry args={[0.067, 14, 10]} />
        <meshStandardMaterial color="#b87958" roughness={0.9} />
      </mesh>
      <mesh position={[0.27, 0.47, 0.02]}>
        <sphereGeometry args={[0.067, 14, 10]} />
        <meshStandardMaterial color="#b87958" roughness={0.9} />
      </mesh>

      {/* Neck */}
      <mesh position={[0, 0.925, 0]} castShadow>
        <cylinderGeometry args={[0.085, 0.095, 0.14, 12]} />
        <meshStandardMaterial color="#b87958" roughness={0.88} />
      </mesh>

      {/* Scarf */}
      <mesh position={[0, 0.91, 0.045]} rotation={[0.04, 0, 0]} castShadow>
        <torusGeometry args={[0.145, 0.027, 8, 24]} />
        <meshStandardMaterial color="#6b1f2a" roughness={0.76} />
      </mesh>
      <mesh position={[0, 0.81, 0.205]} rotation={[0, 0, 0.03]} castShadow>
        <coneGeometry args={[0.075, 0.24, 4]} />
        <meshStandardMaterial color="#6b1f2a" roughness={0.8} />
      </mesh>

      {/* Head */}
      <mesh position={[0, 1.11, 0]} scale={[0.9, 1, 0.9]} castShadow>
        <sphereGeometry args={[0.17, 24, 18]} />
        <meshStandardMaterial color="#b87958" roughness={0.84} />
      </mesh>

      {/* Hair */}
      <mesh position={[0, 1.22, -0.005]} scale={[1.02, 0.62, 1.02]} castShadow>
        <sphereGeometry args={[0.17, 24, 14, 0, Math.PI * 2, 0, Math.PI * 0.58]} />
        <meshStandardMaterial color="#2b211c" roughness={0.92} />
      </mesh>
      <mesh position={[0.09, 1.23, 0.07]} scale={[0.75, 0.6, 0.75]}>
        <sphereGeometry args={[0.06, 16, 10]} />
        <meshStandardMaterial color="#2b211c" roughness={0.92} />
      </mesh>

      {/* Face */}
      <mesh position={[-0.065, 1.125, 0.145]}>
        <sphereGeometry args={[0.018, 12, 8]} />
        <meshStandardMaterial color="#211b18" roughness={0.7} />
      </mesh>
      <mesh position={[0.065, 1.125, 0.145]}>
        <sphereGeometry args={[0.018, 12, 8]} />
        <meshStandardMaterial color="#211b18" roughness={0.7} />
      </mesh>
      <mesh position={[0, 1.075, 0.151]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[0.038, 0.007, 6, 16, Math.PI]} />
        <meshStandardMaterial color="#512f27" roughness={0.85} />
      </mesh>

      {/* Scout hat */}
      <mesh position={[0, 1.285, 0]} castShadow>
        <cylinderGeometry args={[0.16, 0.16, 0.055, 20]} />
        <meshStandardMaterial color="#536847" roughness={0.82} />
      </mesh>
      <mesh position={[0, 1.315, 0]} castShadow>
        <cylinderGeometry args={[0.125, 0.14, 0.07, 20]} />
        <meshStandardMaterial color="#536847" roughness={0.82} />
      </mesh>
      <mesh position={[0, 1.35, 0]}>
        <cylinderGeometry args={[0.022, 0.022, 0.04, 12]} />
        <meshStandardMaterial color="#e7ca68" metalness={0.4} roughness={0.4} />
      </mesh>

      {/* Uniform badges */}
      <Badge position={[-0.085, 0.735, 0.216]} />
      <Badge position={[0.085, 0.735, 0.216]} color="#d9b85c" />
      <Badge position={[0, 0.61, 0.216]} color="#c6d4b1" />

      {/* Staff */}
      <mesh position={[0.43, 0.69, -0.04]} rotation={[0.04, 0, -0.02]}>
        <cylinderGeometry args={[0.014, 0.018, 1.18, 8]} />
        <meshStandardMaterial color="#9b7148" roughness={0.9} />
      </mesh>
      <mesh position={[0.43, 1.29, -0.04]}>
        <coneGeometry args={[0.045, 0.12, 7]} />
        <meshStandardMaterial color="#d6c07d" roughness={0.72} />
      </mesh>
    </group>
  )
}

function Scene() {
  const reduceMotion = useReducedMotion()

  return (
    <>
      <color attach="background" args={['#17221a']} />
      <fog attach="fog" args={['#17221a', 4.5, 8]} />
      <ambientLight intensity={1.55} color="#d2d8c2" />
      <directionalLight position={[-3, 5, 4]} intensity={2.2} color="#f4e4b4" castShadow />
      <directionalLight position={[3, 2, -2]} intensity={0.8} color="#9aa88c" />
      <pointLight position={[1.4, 1.3, 1.6]} intensity={1.8} distance={4} color="#e7a65a" />

      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.06, 0]} receiveShadow>
        <circleGeometry args={[1.65, 64]} />
        <meshStandardMaterial color="#344331" roughness={1} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.055, 0]}>
        <ringGeometry args={[1.54, 1.67, 64]} />
        <meshStandardMaterial color="#756247" roughness={1} />
      </mesh>

      <RaiderCharacter />
      <ContactShadows position={[0, -0.055, 0]} opacity={0.48} scale={2.8} blur={2.5} far={2} />

      <OrbitControls
        enablePan={false}
        enableZoom
        minDistance={2.55}
        maxDistance={4.5}
        minPolarAngle={Math.PI / 2.45}
        maxPolarAngle={Math.PI / 1.95}
        autoRotate={!reduceMotion}
        autoRotateSpeed={0.7}
        target={[0, 0.68, 0]}
      />
    </>
  )
}

export default function RaiderAvatar3D() {
  return (
    <div className="raider-scene" role="group" aria-label="Avatar Raider 3D. Arrastrá para girar y pellizcá o usá la rueda para acercar y alejar.">
      <Canvas shadows camera={{ position: [0, 1.35, 3.55], fov: 35 }} dpr={[1, 1.5]} gl={{ alpha: false, antialias: true }}>
        <Scene />
      </Canvas>
      <span className="scene-drag-hint" aria-hidden="true">GIRÁ · ZOOM <span>↻</span></span>
    </div>
  )
}
