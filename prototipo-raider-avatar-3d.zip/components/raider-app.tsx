'use client'

import { useMemo, useState } from 'react'
import dynamic from 'next/dynamic'
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Award,
  Backpack,
  BookOpen,
  Check,
  ChevronDown,
  Compass,
  Crown,
  Flag,
  Footprints,
  LockKeyhole,
  LogOut,
  Mountain,
  Shield,
  ShieldCheck,
  Sparkles,
  Star,
  Swords,
  TentTree,
  Trees,
  Trophy,
  Users,
  Zap,
} from 'lucide-react'
import type { LucideIcon } from 'lucide-react'

const RaiderAvatar3D = dynamic(() => import('@/components/raider-avatar-3d'), {
  ssr: false,
  loading: () => <div className="raider-scene scene-loading" aria-label="Cargando avatar 3D"><span className="scene-loading-mark"><Compass /></span></div>,
})

type ContentStatus = 'pendiente' | 'en_proceso' | 'aprobado'
type TabId = 'avatar' | 'tree' | 'licenses' | 'companies'
type Content = { id: string; area: string; titulo: string; estado: ContentStatus }
type Raider = {
  dni: string
  pin: string
  nombre: string
  patrulla: string
  etapa_actual: string
  insignia_ala: string
  experiencia_xp: number
  proxima_meta: string
  contenidos_minimos: Content[]
  licencias: { id: string; nombre: string; desbloqueada: boolean; requisitos: string[] }[]
  empresas: { nombre: string; rol: string; estado: string }[]
}

const mockDatabase = {
  comunidad_raider: {
    nombre_grupo: 'Comunidad Raider N° 1',
    raiders: [
      {
        dni: '45123456',
        pin: '1234',
        nombre: 'Lucas González',
        patrulla: 'Yámanas',
        etapa_actual: 'Investidura',
        insignia_ala: 'Fondo Azul',
        experiencia_xp: 1450,
        proxima_meta: 'Realizar Raid de Compromiso',
        contenidos_minimos: [
          { id: 'AS01', area: 'Artes Scouts', titulo: 'Amarre Cuadrado y Diagonal', estado: 'aprobado' },
          { id: 'AS02', area: 'Artes Scouts', titulo: 'Construcción de Mangrullo de 3m', estado: 'en_proceso' },
          { id: 'VA01', area: 'Vida al Aire Libre', titulo: 'Lectura de Carta Topográfica y Brújula', estado: 'aprobado' },
          { id: 'VA02', area: 'Vida al Aire Libre', titulo: 'Acampar con bajo impacto ambiental', estado: 'pendiente' },
          { id: 'PA01', area: 'Primeros Auxilios', titulo: 'RCP y Vendajes de Rescate', estado: 'pendiente' },
          { id: 'ES01', area: 'Animación Espiritual', titulo: 'Vivencia de la Oración Raider', estado: 'aprobado' },
          { id: 'EX01', area: 'Expresión', titulo: 'Diseñar una velada para la Comunidad', estado: 'pendiente' },
          { id: 'CI01', area: 'Ciudadanía', titulo: 'Participar en una acción de servicio', estado: 'en_proceso' },
          { id: 'VS01', area: 'Vida Scout', titulo: 'Conocer la historia y la Ley Scout', estado: 'aprobado' },
        ] as Content[],
        licencias: [
          { id: 'LIC01', nombre: 'Pionerismo y Construcciones', desbloqueada: true, requisitos: ['AS01', 'AS02'] },
          { id: 'LIC02', nombre: 'Primeros Auxilios y Salvamento', desbloqueada: false, requisitos: ['PA01'] },
          { id: 'LIC03', nombre: 'Cartografía y Orientación', desbloqueada: true, requisitos: ['VA01'] },
          { id: 'LIC04', nombre: 'Servicio a la Comunidad', desbloqueada: false, requisitos: ['CI01'] },
          { id: 'LIC05', nombre: 'Expresión y Comunicación', desbloqueada: false, requisitos: ['EX01'] },
          { id: 'LIC06', nombre: 'Vida en la Naturaleza', desbloqueada: false, requisitos: ['VA02'] },
        ],
        empresas: [
          { nombre: 'Remodelación Base-Taller', rol: 'Encargado de Estructura', estado: 'En Ejecución' },
          { nombre: 'Campamento de Verano', rol: 'Logística de Intendencia', estado: 'Finalizada' },
        ],
      },
    ] as Raider[],
  },
}

function isLicenseUnlocked(raider: Raider, license: Raider['licencias'][number]) {
  return license.desbloqueada || license.requisitos.length > 0 && license.requisitos.every((id) => raider.contenidos_minimos.some((item) => item.id === id && item.estado === 'aprobado'))
}

function getLicenseProgress(raider: Raider, license: Raider['licencias'][number]) {
  if (isLicenseUnlocked(raider, license)) return 100
  const requirements = raider.contenidos_minimos.filter((item) => license.requisitos.includes(item.id))
  if (!requirements.length) return 0
  const progress = requirements.reduce((total, item) => total + (item.estado === 'aprobado' ? 100 : item.estado === 'en_proceso' ? 50 : 0), 0)
  return Math.round(progress / requirements.length)
}

const areas = [
  { name: 'Artes Scouts', icon: Backpack, tone: 'amber' },
  { name: 'Vida al Aire Libre', icon: Trees, tone: 'green' },
  { name: 'Primeros Auxilios', icon: ShieldCheck, tone: 'red' },
  { name: 'Expresión', icon: Sparkles, tone: 'violet' },
  { name: 'Animación Espiritual', icon: Star, tone: 'gold' },
  { name: 'Ciudadanía', icon: Users, tone: 'blue' },
  { name: 'Vida Scout', icon: Flag, tone: 'green' },
]

const tabs: { id: TabId; label: string; shortLabel: string; icon: LucideIcon }[] = [
  { id: 'avatar', label: 'Mi Avatar', shortLabel: 'Avatar', icon: Shield },
  { id: 'tree', label: 'Árbol de Progresión', shortLabel: 'Progresión', icon: BookOpen },
  { id: 'licenses', label: 'Licencias y Especialidades', shortLabel: 'Licencias', icon: Award },
  { id: 'companies', label: 'Mis Empresas', shortLabel: 'Empresas', icon: TentTree },
]

const statusLabels: Record<ContentStatus, string> = {
  pendiente: 'Pendiente',
  en_proceso: 'En proceso',
  aprobado: 'Aprobado',
}

const nextStatus: Record<ContentStatus, ContentStatus> = {
  pendiente: 'en_proceso',
  en_proceso: 'aprobado',
  aprobado: 'pendiente',
}

function BrandMark({ small = false }: { small?: boolean }) {
  return (
    <div className={`brand-mark ${small ? 'brand-mark-small' : ''}`} aria-hidden="true">
      <Compass />
    </div>
  )
}

function LoginScreen({ onLogin }: { onLogin: (dni: string) => void }) {
  const [dni, setDni] = useState('45123456')
  const [error, setError] = useState('')

  function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (dni.trim() === mockDatabase.comunidad_raider.raiders[0].dni) {
      onLogin(dni.trim())
    } else {
      setError('No encontramos ese DNI en esta comunidad. Probá con 45123456.')
    }
  }

  return (
    <main className="login-screen">
      <div className="login-topline">
        <a className="brand-lockup" href="#inicio" aria-label="Comunidad Raider, inicio">
          <BrandMark small />
          <span>RAIDER<span className="brand-dot">.</span></span>
        </a>
        <span className="login-community"><span className="live-dot" /> Comunidad Raider N° 1</span>
      </div>
      <div className="login-layout">
        <section className="login-story">
          <div className="eyebrow"><span className="eyebrow-line" /> TU PRÓXIMA AVENTURA EMPIEZA ACÁ</div>
          <h1>El camino<br />se hace <span>andando.</span></h1>
          <p className="login-description">Cada desafío te transforma. Registrá tus avances, desbloqueá nuevas habilidades y descubrí hasta dónde podés llegar.</p>
          <div className="login-trail">
            <div className="trail-stop trail-stop-done"><Check /></div><span className="trail-segment" />
            <div className="trail-stop trail-stop-current"><Footprints /></div><span className="trail-segment trail-segment-muted" />
            <div className="trail-stop trail-stop-next"><Mountain /></div>
            <div className="trail-labels"><span>Explorar</span><span>Superarte</span><span>Trascender</span></div>
          </div>
          <div className="login-quote"><span className="quote-mark">“</span><p>Dejá el mundo un poco mejor de como lo encontraste.</p><span className="quote-credit">— Ley Scout</span></div>
        </section>
        <section className="login-card" aria-labelledby="login-title">
          <div className="login-card-emblem"><BrandMark /></div>
          <div className="eyebrow login-card-eyebrow">INGRESO DE RAIDER</div>
          <h2 id="login-title">Tu aventura te espera</h2>
          <p className="login-card-copy">Ingresá tu DNI para continuar tu camino.</p>
          <form onSubmit={submit} className="login-form">
            <label htmlFor="dni">Documento de identidad</label>
            <div className="dni-input-wrap"><span className="dni-prefix">DNI</span><input id="dni" inputMode="numeric" autoComplete="username" value={dni} onChange={(event) => { setDni(event.target.value); setError('') }} placeholder="Ej. 45123456" aria-describedby={error ? 'login-error' : 'login-hint'} /></div>
            {error ? <p id="login-error" className="login-error" role="alert">{error}</p> : <p id="login-hint" className="login-hint">Para probar, ingresá <strong>45123456</strong></p>}
            <button className="primary-button login-submit" type="submit">Entrar a mi espacio <ArrowRight /></button>
          </form>
          <div className="login-card-foot"><LockKeyhole /> Acceso personal · Comunidad segura</div>
        </section>
      </div>
      <div className="login-footer"><span>Una comunidad, muchos caminos.</span><span>© Comunidad Raider · 2026</span></div>
    </main>
  )
}

function SideNavigation({ activeTab, onSelect, onLogout, raider }: { activeTab: TabId; onSelect: (tab: TabId) => void; onLogout: () => void; raider: Raider }) {
  return (
    <aside className="side-navigation">
      <a className="brand-lockup sidebar-brand" href="#inicio" aria-label="Comunidad Raider">
        <BrandMark small /><span>RAIDER<span className="brand-dot">.</span></span>
      </a>
      <div className="side-community"><span className="community-kicker">TU COMUNIDAD</span><div><span className="community-icon"><Trees /></span><span>{mockDatabase.comunidad_raider.nombre_grupo}</span><ChevronDown /></div></div>
      <span className="nav-section-label">TU ESPACIO</span>
      <nav className="main-nav" aria-label="Navegación principal">
        {tabs.map((tab) => {
          const Icon = tab.icon
          return <button key={tab.id} type="button" onClick={() => onSelect(tab.id)} className={`nav-link ${activeTab === tab.id ? 'nav-link-active' : ''}`} aria-current={activeTab === tab.id ? 'page' : undefined}><Icon /><span>{tab.label}</span>{tab.id === 'tree' && <span className="nav-count">{raider.contenidos_minimos.length}</span>}</button>
        })}
      </nav>
      <div className="sidebar-bottom">
        <div className="sidebar-quest"><div className="quest-icon"><Compass /></div><div><strong>El camino continúa</strong><span>Tu próxima meta está cerca</span></div><ArrowUpRight /></div>
        <div className="sidebar-user"><div className="user-avatar">LG</div><div className="user-details"><strong>{raider.nombre}</strong><span>Patrulla {raider.patrulla}</span></div><button className="logout-button" onClick={onLogout} type="button" aria-label="Cerrar sesión"><LogOut /></button></div>
      </div>
    </aside>
  )
}

function MobileNavigation({ activeTab, onSelect }: { activeTab: TabId; onSelect: (tab: TabId) => void }) {
  return <nav className="mobile-navigation" aria-label="Navegación principal">{tabs.map((tab) => { const Icon = tab.icon; return <button type="button" key={tab.id} onClick={() => onSelect(tab.id)} className={activeTab === tab.id ? 'mobile-nav-active' : ''} aria-current={activeTab === tab.id ? 'page' : undefined}><Icon /><span>{tab.shortLabel}</span></button> })}</nav>
}

function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line" />{eyebrow}</div><h1>{title}</h1><p>{description}</p></div>{action}</div>
}

function AvatarPage({ raider, approvedCount, totalCount, onSelectTab }: { raider: Raider; approvedCount: number; totalCount: number; onSelectTab: (tab: TabId) => void }) {
  const completion = totalCount ? Math.round((approvedCount / totalCount) * 100) : 0
  const inProgressCount = raider.contenidos_minimos.filter((item) => item.estado === 'en_proceso').length
  const unlockedLicenseCount = raider.licencias.filter((license) => isLicenseUnlocked(raider, license)).length
  return <>
    <PageHeading eyebrow="TU HISTORIA, TU CAMINO" title="Mi Avatar" description="Cada paso cuenta. Mirá todo lo que ya lograste." action={<div className="season-pill"><span /> TEMPORADA 2026</div>} />
    <section className="hero-card">
      <div className="hero-orbit hero-orbit-one" /><div className="hero-orbit hero-orbit-two" />
      <div className="hero-content">
        <div className="hero-topline"><span className="hero-kicker"><Sparkles /> TU PERFIL RAIDER</span><span className="hero-rank"><Crown /> ETAPA 02</span></div>
        <div className="hero-main">
          <div className="hero-avatar-art"><RaiderAvatar3D /><span className="avatar-art-caption"><span /> {raider.insignia_ala}</span></div>
          <div className="hero-profile"><div className="hero-name-row"><div><div className="hero-overline">RAIDER DE LA COMUNIDAD</div><h2>{raider.nombre}</h2></div><span className="stage-badge"><span /> {raider.etapa_actual}</span></div><div className="profile-meta"><span><Users /> Patrulla {raider.patrulla}</span><span><Flag /> {mockDatabase.comunidad_raider.nombre_grupo}</span></div><div className="xp-block"><div className="xp-heading"><span><Zap /> EXPERIENCIA</span><strong>{raider.experiencia_xp.toLocaleString('es-AR')} <small>XP</small></strong></div><div className="xp-track"><span style={{ width: `${Math.min((raider.experiencia_xp % 2000) / 20, 100)}%` }} /></div><div className="xp-caption"><span>Nivel 04 <i /> Explorador</span><span>2.000 XP <ArrowRight /></span></div></div></div>
        </div>
      </div>
      <div className="hero-side-note"><span>01</span><span>EL VIAJE<br />ES TUYO</span><ArrowDownRight /></div>
    </section>
    <div className="stats-grid">
      <article className="stat-card"><div className="stat-icon stat-icon-green"><BookOpen /></div><div className="stat-label">CONTENIDOS APROBADOS</div><div className="stat-number">{String(approvedCount).padStart(2, '0')}<span>/{String(totalCount).padStart(2, '0')}</span></div><div className="stat-foot"><span className="mini-progress"><span style={{ width: `${completion}%` }} /></span><span>{completion}% completado</span></div></article>
      <article className="stat-card"><div className="stat-icon stat-icon-gold"><Zap /></div><div className="stat-label">EN PROCESO</div><div className="stat-number">{String(inProgressCount).padStart(2, '0')}<span> desafíos</span></div><div className="stat-foot stat-foot-accent"><ArrowUpRight /> Seguí así, vas muy bien</div></article>
      <article className="stat-card"><div className="stat-icon stat-icon-blue"><Award /></div><div className="stat-label">LICENCIAS LOGRADAS</div><div className="stat-number">{String(unlockedLicenseCount).padStart(2, '0')}<span> insignias</span></div><div className="stat-foot stat-foot-accent"><Sparkles /> Hay nuevas por descubrir</div></article>
    </div>
    <div className="dashboard-lower-grid">
      <section className="panel progress-panel"><div className="panel-heading"><div><div className="panel-eyebrow">TU RECORRIDO</div><h3>Progresión Raider</h3></div><button className="text-link" onClick={() => onSelectTab('tree')} type="button">Ver árbol <ArrowRight /></button></div><div className="progress-overview"><div className="progress-ring" style={{ '--progress': `${completion * 3.6}deg` } as React.CSSProperties}><div><strong>{completion}<small>%</small></strong><span>total</span></div></div><div className="progress-copy"><strong>Vas construyendo<br />tu propio camino.</strong><span>Ya completaste {approvedCount} de {totalCount} contenidos mínimos. Cada experiencia te acerca a tu próxima etapa.</span><button onClick={() => onSelectTab('tree')} type="button">Continuar progresión <ArrowRight /></button></div></div><div className="stage-steps"><div className="stage-step stage-step-done"><span><Check /></span><div><strong>Noviciado</strong><small>Completado</small></div></div><div className="stage-step-connector" /><div className="stage-step stage-step-current"><span>02</span><div><strong>Investidura</strong><small>Etapa actual</small></div></div><div className="stage-step-connector stage-step-connector-muted" /><div className="stage-step stage-step-locked"><span><LockKeyhole /></span><div><strong>Licencia de Servicio</strong><small>Próxima etapa</small></div></div></div></section>
      <section className="goal-card"><div className="goal-topline"><span><Compass /> PRÓXIMO DESAFÍO</span><span className="goal-number">01 / 03</span></div><div className="goal-art"><div className="goal-sun" /><Mountain /><div className="goal-path" /></div><div className="goal-copy"><div className="goal-tag">RAID DE COMPROMISO</div><h3>{raider.proxima_meta}</h3><p>Una travesía para poner a prueba lo aprendido y descubrir de qué estás hecho.</p><button onClick={() => onSelectTab('tree')} type="button">Ver requisitos <ArrowRight /></button></div></section>
    </div>
    <section className="area-overview"><div className="panel-heading"><div><div className="panel-eyebrow">SIETE DIMENSIONES</div><h3>Tu mapa de progresión</h3></div><button className="text-link" onClick={() => onSelectTab('tree')} type="button">Explorar áreas <ArrowRight /></button></div><div className="area-strip">{areas.map((area) => { const Icon = area.icon; const count = raider.contenidos_minimos.filter((item) => item.area === area.name).length; return <button key={area.name} type="button" onClick={() => onSelectTab('tree')} className={`area-chip area-${area.tone}`}><Icon /><span>{area.name}</span><small>{count ? `${count} ${count === 1 ? 'hito' : 'hitos'}` : 'Por descubrir'}</small></button> })}</div></section>
  </>
}

function ProgressTree({ raider, onStatusChange }: { raider: Raider; onStatusChange: (id: string) => void }) {
  const [filter, setFilter] = useState('Todas')
  const filteredAreas = areas.filter((area) => filter === 'Todas' || area.name === filter)
  return <>
    <PageHeading eyebrow="CADA HABILIDAD, UNA AVENTURA" title="Árbol de Progresión" description="Explorá tus contenidos mínimos y registrá cada nuevo aprendizaje." action={<div className="tree-total"><BookOpen /> {raider.contenidos_minimos.length} contenidos</div>} />
    <div className="tree-toolbar"><div className="tree-tabs" role="group" aria-label="Filtrar áreas">{['Todas', ...areas.map((area) => area.name)].map((name) => <button key={name} onClick={() => setFilter(name)} type="button" className={filter === name ? 'tree-tab-active' : ''}>{name === 'Todas' ? 'Todas las áreas' : name}</button>)}</div><span className="tree-hint"><span className="hint-dot" /> Tocá el estado para avanzar</span></div>
    <div className="tree-area-list">{filteredAreas.map((area, index) => { const Icon = area.icon; const contents = raider.contenidos_minimos.filter((item) => item.area === area.name); const done = contents.filter((item) => item.estado === 'aprobado').length; return <section className="tree-area-card" key={area.name}><div className="tree-area-header"><div className={`tree-area-icon area-${area.tone}`}><Icon /></div><div className="tree-area-title"><span>ÁREA {String(index + 1).padStart(2, '0')}</span><h2>{area.name}</h2></div><div className="tree-area-progress"><span>{done} / {contents.length || '—'}</span><div className="tree-mini-track"><i style={{ width: `${contents.length ? done / contents.length * 100 : 0}%` }} /></div></div><ChevronDown className="tree-chevron" /></div>{contents.length ? <div className="content-list">{contents.map((item) => <div className="content-row" key={item.id}><span className={`content-check content-check-${item.estado}`}>{item.estado === 'aprobado' ? <Check /> : item.estado === 'en_proceso' ? <span /> : null}</span><span className="content-id">{item.id}</span><span className="content-name">{item.titulo}</span><button onClick={() => onStatusChange(item.id)} className={`content-status status-${item.estado}`} type="button" aria-label={`Cambiar estado de ${item.titulo}. Estado actual: ${statusLabels[item.estado]}`}><span />{statusLabels[item.estado]}<ChevronDown /></button></div>)}</div> : <div className="empty-area"><Trees /><span>Los desafíos de esta área se sumarán pronto.</span></div>}</section> })}</div>
    <div className="status-legend"><span>Cómo avanzar</span><i className="legend-pending" /> Pendiente <ArrowRight /><i className="legend-progress" /> En proceso <ArrowRight /><i className="legend-approved" /> Aprobado</div>
  </>
}

const licenseDetails: Record<string, { icon: LucideIcon; area: string; requirement: string; tone: string }> = {
  LIC01: { icon: Backpack, area: 'ARTES SCOUTS', requirement: 'Amarres y construcciones', tone: 'green' },
  LIC02: { icon: ShieldCheck, area: 'PRIMEROS AUXILIOS', requirement: 'RCP y vendajes de rescate', tone: 'red' },
  LIC03: { icon: Compass, area: 'VIDA AL AIRE LIBRE', requirement: 'Orientación y cartografía', tone: 'blue' },
  LIC04: { icon: Users, area: 'CIUDADANÍA', requirement: 'Una acción de servicio', tone: 'gold' },
  LIC05: { icon: Sparkles, area: 'EXPRESIÓN', requirement: 'Velada de Comunidad', tone: 'violet' },
  LIC06: { icon: Trees, area: 'VIDA SCOUT', requirement: 'Desafíos al aire libre', tone: 'green' },
}

function LicensesPage({ raider }: { raider: Raider }) {
  const unlockedCount = raider.licencias.filter((license) => isLicenseUnlocked(raider, license)).length
  return <>
    <PageHeading eyebrow="HABILIDADES QUE DEJAN HUELLA" title="Licencias y Especialidades" description="Cada insignia representa algo que sabés hacer y estás listo para compartir." action={<div className="tree-total"><Award /> {unlockedCount} desbloqueadas</div>} />
    <div className="license-feature"><div className="license-feature-icon"><Trophy /></div><div><span>COLECCIÓN DE HABILIDADES</span><h2>El conocimiento también se comparte.</h2><p>Completá los contenidos relacionados para desbloquear una licencia y ponerla al servicio de tu patrulla.</p></div><div className="license-feature-count"><strong>{String(unlockedCount).padStart(2, '0')}</strong><span>de {String(raider.licencias.length).padStart(2, '0')} insignias</span></div></div>
    <div className="license-grid">{raider.licencias.map((license) => { const details = licenseDetails[license.id]; const Icon = details.icon; const unlocked = isLicenseUnlocked(raider, license); const progress = getLicenseProgress(raider, license); return <article className={`license-card ${unlocked ? 'license-unlocked' : 'license-locked'}`} key={license.id}><div className={`license-art license-art-${details.tone}`}><div className="license-art-lines" /><Icon />{unlocked ? <span className="license-check"><Check /></span> : <span className="license-lock"><LockKeyhole /></span>}</div><div className="license-card-body"><div className="license-id">{license.id} <span>·</span> {details.area}</div><h3>{license.nombre}</h3><p>{unlocked ? 'Insignia obtenida. ¡Tu conocimiento suma a la patrulla!' : details.requirement}</p><div className="license-progress-label"><span>{unlocked ? 'DESBLOQUEADA' : 'PROGRESO DEL REQUISITO'}</span><strong>{progress}%</strong></div><div className="license-track"><span className={unlocked ? 'license-track-complete' : ''} style={{ width: `${progress}%` }} /></div></div></article> })}</div>
    <div className="license-note"><ShieldCheck /><p><strong>El valor está en compartir.</strong> Las licencias reconocen tus habilidades, pero su verdadero propósito es ponerlas al servicio de los demás.</p></div>
  </>
}

function CompaniesPage({ raider }: { raider: Raider }) {
  const completed = raider.empresas.filter((company) => company.estado === 'Finalizada').length
  return <>
    <PageHeading eyebrow="AVENTURAS QUE HACEMOS EN EQUIPO" title="Mis Empresas" description="Proyectos compartidos, desafíos reales y recuerdos que quedan." action={<div className="tree-total"><TentTree /> {raider.empresas.length} proyectos</div>} />
    <section className="company-hero"><div className="company-hero-copy"><div className="eyebrow"><span className="eyebrow-line" /> EL ESPÍRITU DE EMPRESA</div><h2>Las grandes cosas<br />se hacen <span>en equipo.</span></h2><p>Cada empresa empieza con una idea y crece con el aporte de todos. Este es tu recorrido junto a la patrulla.</p><div className="company-stats"><span><strong>{String(raider.empresas.length).padStart(2, '0')}</strong> EMPRESAS</span><i /><span><strong>{String(completed).padStart(2, '0')}</strong> FINALIZADAS</span><i /><span><strong>{String(raider.empresas.length - completed).padStart(2, '0')}</strong> EN CURSO</span></div></div><div className="company-hero-art"><div className="company-sun" /><Trees className="company-tree company-tree-one" /><Trees className="company-tree company-tree-two" /><TentTree className="company-tent" /><div className="company-campfire"><span /><i /><b /></div><span className="camp-label">PATRULLA YÁMANAS · EN TERRENO</span></div></section>
    <div className="company-section-heading"><div><div className="panel-eyebrow">BITÁCORA DE EQUIPO</div><h3>Tu recorrido en empresas</h3></div><span><span className="live-dot" /> {mockDatabase.comunidad_raider.nombre_grupo}</span></div>
    <div className="company-list">{raider.empresas.map((company, index) => <article className="company-card" key={company.nombre}><div className={`company-index ${company.estado === 'Finalizada' ? 'company-index-done' : ''}`}>{company.estado === 'Finalizada' ? <Check /> : String(index + 1).padStart(2, '0')}</div><div className="company-card-main"><span>EMPRESA · {String(index + 1).padStart(2, '0')}</span><h3>{company.nombre}</h3><div className="company-role"><Users /> Tu rol <strong>{company.rol}</strong></div></div><div className={`company-status ${company.estado === 'Finalizada' ? 'company-status-done' : ''}`}><i />{company.estado}</div><button className="company-open" type="button" aria-label={`Ver empresa ${company.nombre}`}><ArrowUpRight /></button></article>)}</div>
    <div className="company-bottom-note"><Swords /><span>Las empresas son proyectos de la patrulla: elegí un desafío, sumá tu talento y construyan algo juntos.</span><Flag /></div>
  </>
}

export function RaiderApp() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [activeTab, setActiveTab] = useState<TabId>('avatar')
  const [raider, setRaider] = useState<Raider>(() => structuredClone(mockDatabase.comunidad_raider.raiders[0]))
  const approvedCount = useMemo(() => raider.contenidos_minimos.filter((item) => item.estado === 'aprobado').length, [raider.contenidos_minimos])

  if (!loggedIn) return <LoginScreen onLogin={() => { setRaider(structuredClone(mockDatabase.comunidad_raider.raiders[0])); setLoggedIn(true) }} />

  function updateContentStatus(id: string) {
    setRaider((current) => {
      const contents = current.contenidos_minimos.map((item) => item.id === id ? { ...item, estado: nextStatus[item.estado] } : item)
      const oldItem = current.contenidos_minimos.find((item) => item.id === id)
      const newItem = contents.find((item) => item.id === id)
      const xpChange = (newItem?.estado === 'aprobado' ? 50 : 0) - (oldItem?.estado === 'aprobado' ? 50 : 0)
      return { ...current, contenidos_minimos: contents, experiencia_xp: current.experiencia_xp + xpChange }
    })
  }

  return <main className="app-shell">
    <SideNavigation activeTab={activeTab} onSelect={setActiveTab} onLogout={() => { setLoggedIn(false); setActiveTab('avatar') }} raider={raider} />
    <div className="workspace"><header className="topbar"><div className="topbar-location"><span>MI ESPACIO</span><ArrowRight /><strong>{tabs.find((tab) => tab.id === activeTab)?.label}</strong></div><div className="topbar-right"><span className="topbar-date">CICLO RAIDER <i /> 2026</span><button className="topbar-patrol" type="button"><span className="patrol-avatar"><Trees /></span><span><small>MI PATRULLA</small><strong>{raider.patrulla}</strong></span><ChevronDown /></button><div className="topbar-user">LG</div></div></header>
      <div className="mobile-brand"><BrandMark small /><span>RAIDER<span className="brand-dot">.</span></span><button type="button" onClick={() => setLoggedIn(false)} aria-label="Cerrar sesión"><LogOut /></button></div>
      <div className="page-content">{activeTab === 'avatar' && <AvatarPage raider={raider} approvedCount={approvedCount} totalCount={raider.contenidos_minimos.length} onSelectTab={setActiveTab} />}{activeTab === 'tree' && <ProgressTree raider={raider} onStatusChange={updateContentStatus} />}{activeTab === 'licenses' && <LicensesPage raider={raider} />}{activeTab === 'companies' && <CompaniesPage raider={raider} />}</div>
      <footer className="workspace-footer"><span>HECHO PARA EXPLORAR, APRENDER Y SERVIR.</span><span>COMUNIDAD RAIDER N° 1 <i /> 2026</span></footer>
    </div>
    <MobileNavigation activeTab={activeTab} onSelect={setActiveTab} />
  </main>
}

export default RaiderApp
